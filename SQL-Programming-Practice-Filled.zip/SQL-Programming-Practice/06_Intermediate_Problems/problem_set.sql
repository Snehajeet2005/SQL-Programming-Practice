-- Intermediate SQL Problem Set

-- 1. Find the second-highest DISTINCT salary.
SELECT MAX(salary) AS second_highest
FROM employees
WHERE salary < (SELECT MAX(salary) FROM employees);

-- 2. Find the third-highest DISTINCT salary.
SELECT MAX(salary) AS third_highest
FROM employees
WHERE salary < (
    SELECT MAX(salary)
    FROM employees
    WHERE salary < (SELECT MAX(salary) FROM employees)
);

-- 3. Find employees whose salary is above their department's average.
SELECT e.*
FROM employees e
WHERE e.salary > (
    SELECT AVG(e2.salary)
    FROM employees e2
    WHERE e2.department_id = e.department_id
);

-- 4. Find the highest-paid employee in each department.
SELECT e.*
FROM employees e
WHERE e.salary = (
    SELECT MAX(e2.salary)
    FROM employees e2
    WHERE e2.department_id = e.department_id
);

-- 5. Find customers who have placed at least one order.
SELECT DISTINCT c.customer_name
FROM customers c
JOIN orders o ON c.customer_id = o.customer_id;

-- 6. Find customers who have never placed an order.
SELECT c.*
FROM customers c
LEFT JOIN orders o ON c.customer_id = o.customer_id
WHERE o.order_id IS NULL;

-- 7. Find the total order amount for each customer.
SELECT c.customer_name, COALESCE(SUM(o.amount), 0) AS total_amount
FROM customers c
LEFT JOIN orders o ON c.customer_id = o.customer_id
GROUP BY c.customer_name;

-- 8. Find customers whose total completed orders exceed 3000.
SELECT c.customer_name, SUM(o.amount) AS completed_total
FROM customers c
JOIN orders o ON c.customer_id = o.customer_id
WHERE o.status = 'Completed'
GROUP BY c.customer_name
HAVING SUM(o.amount) > 3000;

-- 9. Count orders by status.
SELECT status, COUNT(*) AS order_count
FROM orders
GROUP BY status;

-- 10. Find the highest-value completed order.
SELECT *
FROM orders
WHERE status = 'Completed'
  AND amount = (
      SELECT MAX(amount)
      FROM orders
      WHERE status = 'Completed'
  );
