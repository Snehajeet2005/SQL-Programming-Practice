-- Beginner to Intermediate: Aggregation
-- 1. Count all employees.
SELECT COUNT(*) AS employee_count FROM employees;

-- 2. Find the highest salary.
SELECT MAX(salary) AS highest_salary FROM employees;

-- 3. Find the average salary.
SELECT AVG(salary) AS average_salary FROM employees;

-- 4. Find total salary paid by the company.
SELECT SUM(salary) AS total_salary FROM employees;

-- 5. Find the number of employees in each department.
SELECT department_id, COUNT(*) AS employee_count
FROM employees
GROUP BY department_id;

-- 6. Find average salary in each department.
SELECT department_id, AVG(salary) AS average_salary
FROM employees
GROUP BY department_id;

-- 7. Show departments having more than 2 employees.
SELECT department_id, COUNT(*) AS employee_count
FROM employees
GROUP BY department_id
HAVING COUNT(*) > 2;

-- 8. Find the maximum salary in each city.
SELECT city, MAX(salary) AS maximum_salary
FROM employees
GROUP BY city;
