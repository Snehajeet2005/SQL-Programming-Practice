-- schema.sql
-- Sample database used by the practice problems

CREATE TABLE departments (
    department_id INT PRIMARY KEY,
    department_name VARCHAR(50)
);

CREATE TABLE employees (
    employee_id INT PRIMARY KEY,
    employee_name VARCHAR(100),
    department_id INT,
    salary DECIMAL(10,2),
    hire_date DATE,
    manager_id INT,
    city VARCHAR(50),
    FOREIGN KEY (department_id) REFERENCES departments(department_id)
);

CREATE TABLE customers (
    customer_id INT PRIMARY KEY,
    customer_name VARCHAR(100),
    city VARCHAR(50)
);

CREATE TABLE orders (
    order_id INT PRIMARY KEY,
    customer_id INT,
    order_date DATE,
    amount DECIMAL(10,2),
    status VARCHAR(20),
    FOREIGN KEY (customer_id) REFERENCES customers(customer_id)
);

INSERT INTO departments VALUES
(1, 'IT'), (2, 'HR'), (3, 'Finance'), (4, 'Sales'), (5, 'Marketing');

INSERT INTO employees VALUES
(101, 'Amit', 1, 65000, '2022-01-10', NULL, 'Kolkata'),
(102, 'Priya', 1, 72000, '2021-06-15', 101, 'Delhi'),
(103, 'Rahul', 2, 48000, '2023-02-20', NULL, 'Kolkata'),
(104, 'Sneha', 3, 58000, '2022-08-01', NULL, 'Mumbai'),
(105, 'Arjun', 4, 52000, '2023-04-12', NULL, 'Delhi'),
(106, 'Neha', 4, 61000, '2020-11-25', 105, 'Kolkata'),
(107, 'Rohan', 1, 55000, '2024-01-05', 101, 'Pune'),
(108, 'Isha', 5, 50000, '2023-09-18', NULL, 'Mumbai'),
(109, 'Karan', 3, 67000, '2021-03-11', 104, 'Delhi'),
(110, 'Ananya', 2, 45000, '2024-02-14', 103, 'Pune');

INSERT INTO customers VALUES
(1, 'Customer A', 'Kolkata'),
(2, 'Customer B', 'Delhi'),
(3, 'Customer C', 'Mumbai'),
(4, 'Customer D', 'Pune'),
(5, 'Customer E', 'Kolkata');

INSERT INTO orders VALUES
(1001, 1, '2025-01-05', 1200, 'Completed'),
(1002, 2, '2025-01-08', 2500, 'Completed'),
(1003, 1, '2025-02-12', 1800, 'Pending'),
(1004, 3, '2025-02-20', 3200, 'Completed'),
(1005, 4, '2025-03-03', 900, 'Cancelled'),
(1006, 5, '2025-03-10', 2100, 'Completed'),
(1007, 2, '2025-03-15', 1500, 'Pending'),
(1008, 3, '2025-04-01', 4000, 'Completed');
