# SQL Practice Questions

1. Display all employees.
2. Display employee names and salaries.
3. Find employees earning above 60000.
4. Find employees from Kolkata.
5. Find salaries between 50000 and 65000.
6. Find employees in IT or Finance.
7. Find names beginning with A.
8. Sort employees by salary descending.
9. Display distinct cities.
10. Count employees.
11. Find maximum, minimum and average salary.
12. Count employees in each department.
13. Find departments with more than two employees.
14. Join employees with departments.
15. Show departments even when they have no employees.
16. Display employees and their managers.
17. Find employees earning above average salary.
18. Find the highest-paid employee.
19. Find the second-highest salary.
20. Find employees above their department average.
21. Find customers who placed orders.
22. Find customers who never placed orders.
23. Calculate total order value per customer.
24. Find customers with completed orders above 3000.
25. Count orders by status.
26. Find the highest-value completed order.
27. Categorize employees by salary using CASE.
28. Use string functions on employee names.
29. Create and query a view.
30. Practice UNION and UNION ALL.
