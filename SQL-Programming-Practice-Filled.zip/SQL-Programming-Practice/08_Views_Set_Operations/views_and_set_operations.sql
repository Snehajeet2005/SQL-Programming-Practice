-- Views and set operations

-- 1. Create a view of high-paid employees.
CREATE VIEW high_paid_employees AS
SELECT employee_id, employee_name, salary
FROM employees
WHERE salary >= 60000;

-- 2. Query the view.
SELECT * FROM high_paid_employees;

-- 3. UNION example: cities appearing in employees and customers.
SELECT city FROM employees
UNION
SELECT city FROM customers;

-- 4. UNION ALL example.
SELECT city FROM employees
UNION ALL
SELECT city FROM customers;

-- Drop the view after practice if required.
-- DROP VIEW high_paid_employees;
