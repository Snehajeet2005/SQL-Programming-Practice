-- Intermediate: Subqueries
-- 1. Find employees earning more than the average salary.
SELECT *
FROM employees
WHERE salary > (SELECT AVG(salary) FROM employees);

-- 2. Find the employee(s) with the highest salary.
SELECT *
FROM employees
WHERE salary = (SELECT MAX(salary) FROM employees);

-- 3. Find employees earning more than the salary of Amit.
SELECT *
FROM employees
WHERE salary > (SELECT salary FROM employees WHERE employee_name = 'Amit');

-- 4. Find employees who work in the IT department using a subquery.
SELECT *
FROM employees
WHERE department_id = (
    SELECT department_id
    FROM departments
    WHERE department_name = 'IT'
);

-- 5. Find departments whose average salary is greater than 55000.
SELECT department_id, AVG(salary) AS avg_salary
FROM employees
GROUP BY department_id
HAVING AVG(salary) > 55000;

-- 6. Find the second-highest salary.
SELECT MAX(salary) AS second_highest
FROM employees
WHERE salary < (SELECT MAX(salary) FROM employees);
