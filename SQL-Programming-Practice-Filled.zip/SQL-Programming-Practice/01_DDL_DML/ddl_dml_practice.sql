-- DDL and DML practice

-- 1. Create a students table with id, name, age and marks.
CREATE TABLE students (
    student_id INT PRIMARY KEY,
    student_name VARCHAR(100),
    age INT,
    marks DECIMAL(5,2)
);

-- 2. Add an email column.
ALTER TABLE students ADD email VARCHAR(100);

-- 3. Insert sample records.
INSERT INTO students VALUES
(1, 'Rahul', 20, 82.5, 'rahul@example.com'),
(2, 'Priya', 21, 91.0, 'priya@example.com');

-- 4. Update Rahul's marks.
UPDATE students
SET marks = 85
WHERE student_id = 1;

-- 5. Delete a student.
DELETE FROM students
WHERE student_id = 2;

-- 6. Remove the table when finished.
-- DROP TABLE students;
