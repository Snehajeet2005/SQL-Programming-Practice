# SQL Programming Practice

A beginner-to-intermediate SQL practice repository covering database creation, data manipulation, querying, aggregation, joins, subqueries, and common SQL problem-solving techniques.

This repository is intended to document hands-on SQL practice and strengthen practical skills for database and coding assessments.

## Topics Covered
- DDL and DML
- SELECT, WHERE, ORDER BY, DISTINCT
- Filtering with LIKE, IN and BETWEEN
- Aggregate functions and GROUP BY/HAVING
- INNER, LEFT and SELF JOINs
- Subqueries
- CASE expressions
- String and numeric functions
- Views and set operations
- Beginner-to-intermediate SQL problems

## Database
The examples use commonly supported SQL syntax. Minor changes may be required depending on the database system (MySQL, Oracle, PostgreSQL, etc.).

## Note
The problem set is for learning and practice. Solutions should be understood and tested rather than treated as a substitute for hands-on practice.
