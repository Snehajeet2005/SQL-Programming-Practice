-- CASE, string and numeric functions

-- 1. Categorize employees by salary.
SELECT employee_name, salary,
       CASE
           WHEN salary >= 65000 THEN 'High'
           WHEN salary >= 50000 THEN 'Medium'
           ELSE 'Low'
       END AS salary_category
FROM employees;

-- 2. Display employee names in uppercase.
SELECT UPPER(employee_name) AS employee_name
FROM employees;

-- 3. Display the length of each employee name.
SELECT employee_name, LENGTH(employee_name) AS name_length
FROM employees;

-- 4. Increase salary by 10% for employees earning below 50000.
-- Practice query; execute only if you intend to modify the sample data.
-- UPDATE employees SET salary = salary * 1.10 WHERE salary < 50000;

-- 5. Show completed orders as 'Yes' and other orders as 'No'.
SELECT order_id,
       CASE WHEN status = 'Completed' THEN 'Yes' ELSE 'No' END AS completed
FROM orders;
