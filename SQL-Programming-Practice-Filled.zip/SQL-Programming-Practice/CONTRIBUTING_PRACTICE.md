# How to Use This Repository

For each problem:
1. Read the question without looking at the solution.
2. Write the query yourself.
3. Run it against the sample schema.
4. Compare your query with the solution.
5. Be able to explain why your query works and its basic complexity/behavior.

For a placement application, only claim SQL topics that you have actually practiced and can explain.
