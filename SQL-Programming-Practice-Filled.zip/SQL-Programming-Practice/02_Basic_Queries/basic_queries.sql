-- Beginner: Basic SELECT, filtering and sorting
-- 1. Display all employees.
SELECT * FROM employees;

-- 2. Display employee names and salaries.
SELECT employee_name, salary FROM employees;

-- 3. Find employees earning more than 60000.
SELECT * FROM employees WHERE salary > 60000;

-- 4. Find employees from Kolkata.
SELECT * FROM employees WHERE city = 'Kolkata';

-- 5. Find employees with salary between 50000 and 65000.
SELECT * FROM employees WHERE salary BETWEEN 50000 AND 65000;

-- 6. Find employees in IT or Finance.
SELECT * FROM employees WHERE department_id IN (1, 3);

-- 7. Find names beginning with A.
SELECT * FROM employees WHERE employee_name LIKE 'A%';

-- 8. Sort employees by salary from highest to lowest.
SELECT * FROM employees ORDER BY salary DESC;

-- 9. Display distinct employee cities.
SELECT DISTINCT city FROM employees;

-- 10. Find employees whose salary is not 50000.
SELECT * FROM employees WHERE salary <> 50000;
